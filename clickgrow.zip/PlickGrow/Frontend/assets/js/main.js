/* ClickGrown interaction layer: mobile navigation, counters, and newsletter feedback. */
document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  document.querySelector('#year').textContent = new Date().getFullYear();

  const menuButton = document.querySelector('#menu-button');
  const mobileMenu = document.querySelector('#mobile-menu');
  menuButton.addEventListener('click', () => {
    const isOpen = !mobileMenu.classList.contains('hidden');
    mobileMenu.classList.toggle('hidden', isOpen);
    menuButton.setAttribute('aria-expanded', String(!isOpen));
  });
  mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    mobileMenu.classList.add('hidden'); menuButton.setAttribute('aria-expanded', 'false');
  }));

  const counters = document.querySelectorAll('[data-count]');
  const counterObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const element = entry.target; const target = Number(element.dataset.count); const prefix = element.dataset.prefix || ''; const suffix = element.dataset.suffix || '';
    const start = performance.now(); const duration = 1300;
    const update = now => { const value = Math.min(target, Math.floor(target * ((now - start) / duration))); element.textContent = `${prefix}${value}${suffix}`; if (value < target) requestAnimationFrame(update); };
    requestAnimationFrame(update); counterObserver.unobserve(element);
  }), { threshold: 0.5 });
  counters.forEach(counter => counterObserver.observe(counter));

  document.querySelector('#newsletter-form').addEventListener('submit', event => {
    event.preventDefault(); event.currentTarget.reset(); document.querySelector('#form-message').classList.remove('hidden');
  });
});
