from django.test import TestCase
from django.urls import reverse


class AuthenticationFlowTests(TestCase):
    def test_registration_redirects_to_login(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'growthuser', 'email': 'growth@example.com',
            'password1': 'StrongPass!2026', 'password2': 'StrongPass!2026',
        })
        self.assertRedirects(response, reverse('accounts:login'))

    def test_api_registration_returns_created_user(self):
        response = self.client.post(reverse('accounts:api_register'), {
            'username': 'apiuser', 'email': 'api@example.com',
            'password1': 'StrongPass!2026', 'password2': 'StrongPass!2026',
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()['user']['username'], 'apiuser')
