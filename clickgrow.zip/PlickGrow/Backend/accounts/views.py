"""Account views for both server-rendered pages and JSON API clients."""
import json

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_POST

from .forms import LoginForm, RegistrationForm


def home(request):
    """Public landing page; greeting and account actions adapt to session state."""
    return render(request, 'accounts/home.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('accounts:home')
    form = RegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Account created. Sign in to start growing.')
        return redirect('accounts:login')
    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('accounts:home')
    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        login(request, form.get_user())
        messages.success(request, f'Welcome back, {request.user.username}!')
        return redirect(request.POST.get('next') or 'accounts:home')
    return render(request, 'accounts/login.html', {'form': form, 'next': request.GET.get('next', '')})


@require_POST
def logout_view(request):
    logout(request)
    messages.info(request, 'You have been signed out.')
    return redirect('accounts:login')


def _payload(request):
    """Read JSON APIs and conventional form submissions through one validation path."""
    if request.content_type and 'application/json' in request.content_type:
        try:
            return json.loads(request.body or '{}')
        except json.JSONDecodeError:
            return None
    return request.POST


@require_POST
def api_register(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({'detail': 'Invalid JSON payload.'}, status=400)
    form = RegistrationForm(data)
    if not form.is_valid():
        return JsonResponse({'detail': 'Validation failed.', 'errors': form.errors.get_json_data()}, status=400)
    user = form.save()
    return JsonResponse({'message': 'Registration successful. Please log in.', 'user': {'id': user.id, 'username': user.username, 'email': user.email}}, status=201)


@require_POST
def api_login(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({'detail': 'Invalid JSON payload.'}, status=400)
    username, password = data.get('username', ''), data.get('password', '')
    user = authenticate(request, username=username, password=password)
    if user is None:
        return JsonResponse({'detail': 'Invalid username or password.'}, status=400)
    login(request, user)
    return JsonResponse({'message': 'Login successful.', 'user': {'id': user.id, 'username': user.username, 'email': user.email}})


@require_POST
def api_logout(request):
    logout(request)
    return JsonResponse({'message': 'Logout successful.'})


@require_GET
def api_me(request):
    if not request.user.is_authenticated:
        return JsonResponse({'detail': 'Authentication required.'}, status=401)
    user = request.user
    return JsonResponse({'id': user.id, 'username': user.username, 'email': user.email, 'is_authenticated': True})
