# ClickGrown Django Backend

The Django application provides session-based registration and login, a protected dashboard-style home page, and JSON endpoints for client integrations. It uses SQLite (`db.sqlite3`) by default.

## Run locally

```powershell
cd Backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Open `http://127.0.0.1:8000/`. Create an account at `/register/`, then sign in at `/login/`.

## API endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register/` | Create an account |
| POST | `/api/auth/login/` | Sign in and start a session |
| POST | `/api/auth/logout/` | End the current session |
| GET | `/api/auth/me/` | Current authenticated user |

POST endpoints accept JSON (`application/json`) or form fields. Include Django's CSRF token for browser-based session requests.
