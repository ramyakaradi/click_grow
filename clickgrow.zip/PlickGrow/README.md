# ClickGrown

## Project structure

- `Frontend/` — responsive HTML, Tailwind-powered styles, and client-side interactions.
- `Backend/` — reserved for server-side features.

Open `Frontend/index.html` in a browser to preview the landing page. The project uses Tailwind and Lucide Icons via CDN, so an internet connection is needed for the external design assets.
